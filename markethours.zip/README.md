# MarketHours
Simple console app to show which markets are currently open.


Written with C# using Microsoft Visual Studio Community 2019 Preview Version 16.5.0 Preview 3.0


